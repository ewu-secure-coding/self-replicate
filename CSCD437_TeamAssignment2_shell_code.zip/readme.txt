Tim Unger, Will Czifro, Sam Gronhovd
shell-code
Team Assignment 2 Self Replicating Program

Shortcomings- Works on Linux/Mac, Windows version is currently not working. Program return source code stabilizes after 2 runs from original source.

Extra Credit Attempted.

To run- 
In the terminal cd to the .jar;

java -jar self-replicate.jar 5 -s 

This is the recommended command line command. Will run 5 times while printing progress to console. 

From included README.md, 

## How to use

1. cd to location of .java
2. create output directory of compiling files `mkdir classes`
3. compile Java files `javac -d classes Main.java Replicator.java UnixBasedReplicator.java WindowsBasedReplicator.java`
4. create Jar file `jar -cfm ../../self-replicate.jar ../META-INF/MANIFEST.MF Main.class Replicator.class UnixBasedReplicator.class WindowsBasedReplicator.class`
5. cd to Jar file
6. execute jar file `java -jar self-replicate.jar [number] -{xspdci}`

number: specifies number of generations to create, optional

-x: specifies that each generation should cleanup any files and folders required to create the next generation
-s: specifies that std out and std err outputs should be tunneled back to console
-p: specifies that a generation should delete its parent and pass its location to its child
-d: specifies program should halt after decompiling itself, use for debugging
-c: specifies program should halt after compiling source for next generation, use for debugging
-i: specifies that program should run indefinitely, may result in computer crash due to either no storage or RAM space