// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   WindowsBasedReplicator.java

import java.io.*;
import java.net.URL;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.nio.file.*;
import java.nio.file.attribute.FileAttribute;

public class WindowsBasedReplicator extends Replicator
{

    public WindowsBasedReplicator()
    {
    }

    public void selfReplicate(int i, String s, String s1)
        throws Exception
    {
        System.out.println("Self Replicating...");
        File file = new File(newDir);
        file.mkdir();
        parseFlags(s);
        fetchDecompiler();
        unjarSelf();
        if(onlyDecompileFlag)
        {
            System.out.println("Halting program...");
            System.exit(0);
        }
        compileNewSource();
        if(onlyCompileFlag)
        {
            if(cleanupFlag)
                cleanup(null);
            System.out.println("Halting program...");
            System.exit(0);
        }
        if(cleanupFlag)
            cleanup(s1);
        if(i > 0)
            startReplicate(i, s);
    }

    protected void fetchDecompiler()
        throws Exception
    {
        System.out.println("Fetching decompiler...");
        URL url = new URL(jadUrl());
        java.nio.channels.ReadableByteChannel readablebytechannel = Channels.newChannel(url.openStream());
        FileOutputStream fileoutputstream = new FileOutputStream("jadZip.zip");
        fileoutputstream.getChannel().transferFrom(readablebytechannel, 0L, 0xffffffffL);
        Files.createDirectory((new File((new StringBuilder()).append(currentDir).append("\\jadFiles").toString())).toPath(), new FileAttribute[0]);
        ProcessBuilder processbuilder = new ProcessBuilder(new String[] {
            "jar", "-xf", "..\\jadZip.zip"
        });
        processbuilder = processbuilder.directory(new File((new StringBuilder()).append(currentDir).append("\\jadFiles").toString()));
        Process process = processbuilder.start();
        process.waitFor();
        Files.copy((new File((new StringBuilder()).append(currentDir).append("\\jadFiles\\jad.exe").toString())).toPath(), (new File((new StringBuilder()).append(newDir).append("\\jad.exe").toString())).toPath(), new CopyOption[] {
            StandardCopyOption.REPLACE_EXISTING
        });
        File file = new File((new StringBuilder()).append(currentDir).append("\\jadZip.zip").toString());
        file.delete();
        removeTree((new StringBuilder()).append(currentDir).append("\\jadFiles").toString());
    }

    protected void unjarSelf()
        throws Exception
    {
        System.out.println("Unjarring self...");
        String s = (new StringBuilder()).append(newDir).append("\\classes").toString();
        File file = new File(s);
        file.mkdir();
        ProcessBuilder processbuilder = new ProcessBuilder(new String[] {
            "jar", "-xf", "..\\..\\self-replicate.jar"
        });
        processbuilder = processbuilder.directory(new File(s));
        Process process = processbuilder.start();
        process.waitFor();
        decompileClasses(s);
    }

    protected void decompileClasses(String s)
        throws Exception
    {
        System.out.println("Decompiling classes...");
        File file = new File((new StringBuilder()).append(newDir).append("..\\src").toString());
        file.mkdir();
        ProcessBuilder processbuilder = new ProcessBuilder(new String[] {
            "jad.exe", "-o", "-dsrc", "-sjava", "classes\\*.class"
        });
        processbuilder = processbuilder.directory(new File(newDir));
        Process process = processbuilder.start();
        process.waitFor();
    }

    protected void compileNewSource()
        throws Exception
    {
        System.out.println("Compile java...");
        String s = (new StringBuilder()).append(newDir).append("\\src").toString();
        File file = new File((new StringBuilder()).append(s).append("\\classes").toString());
        file.mkdir();
        ProcessBuilder processbuilder = new ProcessBuilder(new String[] {
            "javac", "-d", "classes", "Main.java", "Replicator.java", "UnixBasedReplicator.java", "WindowsBasedReplicator.java"
        });
        processbuilder = processbuilder.directory(new File(s));
        Process process = processbuilder.start();
        process.waitFor();
        processbuilder = new ProcessBuilder(new String[] {
            "java", "-cp", "./classes;.", "classes\\*.class"
        });
        processbuilder = processbuilder.directory(new File(s));
        process = processbuilder.start();
        process.waitFor();
        createManifest(s);
        processbuilder = new ProcessBuilder(new String[] {
            "jar", "-cfm", "..\\..\\self-replicate.jar", "manifest.txt", "Main.class", "Replicator.class", "UnixBasedReplicator.class", "WindowsBasedReplicator.class"
        });
        processbuilder = processbuilder.directory(new File((new StringBuilder()).append(s).append("\\classes").toString()));
        process = processbuilder.start();
        process.waitFor();
    }

    protected void cleanup(String s)
        throws Exception
    {
        removeTree((new StringBuilder()).append(newDir).append("\\classes").toString());
        removeTree((new StringBuilder()).append(newDir).append("\\src").toString());
        Files.delete((new File((new StringBuilder()).append(newDir).append("\\src").toString())).toPath());
        Files.delete((new File((new StringBuilder()).append(newDir).append("\\jad.exe").toString())).toPath());
        if(s != null)
        {
            System.out.println("Deleting parent...");
            Files.delete((new File(s)).toPath());
        }
    }

    protected void startReplicate(int i, String s)
        throws Exception
    {
        System.out.println("Starting replicate and terminating self...");
        Object obj = null;
        ProcessBuilder processbuilder = null;
        if(i != -1)
        {
            if(s != null)
            {
                if(deleteParentFlag)
                {
                    String s1 = (new StringBuilder()).append("java -jar self-replicate.jar ").append(Integer.toString(i)).append(" ").append(s).append(" ").append(currentDir).append("/self-replicate.jar").toString();
                    processbuilder = new ProcessBuilder(new String[] {
                        "java", "-jar", "self-replicate.jar", Integer.toString(i), s, (new StringBuilder()).append(currentDir).append("/self-replicate.jar").toString()
                    });
                } else
                {
                    String s2 = (new StringBuilder()).append("java -jar self-replicate.jar ").append(Integer.toString(i)).append(" ").append(s).toString();
                    processbuilder = new ProcessBuilder(new String[] {
                        "java", "-jar", "self-replicate.jar", Integer.toString(i), s
                    });
                }
            } else
            {
                String s3 = (new StringBuilder()).append("java -jar self-replicate.jar ").append(Integer.toString(i)).toString();
                processbuilder = new ProcessBuilder(new String[] {
                    "java", "-jar", "self-replicate.jar", Integer.toString(i)
                });
            }
        } else
        if(s != null)
        {
            if(deleteParentFlag)
            {
                String s4 = (new StringBuilder()).append("java -jar self-replicate.jar  ").append(s).append(" ").append(currentDir).append("/self-replicate.jar").toString();
                processbuilder = new ProcessBuilder(new String[] {
                    "java", "-jar", "self-replicate.jar", s, (new StringBuilder()).append(currentDir).append("/self-replicate.jar").toString()
                });
            } else
            {
                String s5 = (new StringBuilder()).append("java -jar self-replicate.jar  ").append(s).toString();
                processbuilder = new ProcessBuilder(new String[] {
                    "java", "-jar", "self-replicate.jar", s
                });
            }
        } else
        {
            String s6 = "java -jar self-replicate.jar";
            processbuilder = new ProcessBuilder(new String[] {
                "java", "-jar", "self-replicate.jar"
            });
        }
        processbuilder = processbuilder.directory(new File(newDir));
        Process process = processbuilder.start();
        if(showChildOutputFlag)
        {
            String s7 = null;
            BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            BufferedReader bufferedreader1 = new BufferedReader(new InputStreamReader(process.getErrorStream()));
            System.out.println("Here is the standard output of the command:\n");
            while((s7 = bufferedreader.readLine()) != null) 
                System.out.println(s7);
            System.out.println("Here is the standard error of the command (if any):\n");
            while((s7 = bufferedreader1.readLine()) != null) 
                System.out.println(s7);
        }
        System.exit(0);
    }

    private void removeTree(String s)
    {
        File file = new File(s);
        String as[] = file.list();
        String as1[] = as;
        int i = as1.length;
        for(int j = 0; j < i; j++)
        {
            String s1 = as1[j];
            File file1 = new File(s1);
            if(file1.isDirectory())
                removeTree(s1);
            file1.delete();
        }

        file.delete();
    }
}
