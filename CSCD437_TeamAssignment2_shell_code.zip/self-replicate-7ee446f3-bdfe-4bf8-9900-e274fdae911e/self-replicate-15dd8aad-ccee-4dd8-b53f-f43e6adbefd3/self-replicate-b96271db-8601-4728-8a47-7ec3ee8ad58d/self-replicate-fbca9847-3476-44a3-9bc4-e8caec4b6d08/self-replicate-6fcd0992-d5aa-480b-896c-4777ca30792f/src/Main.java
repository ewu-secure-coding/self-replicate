// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Main.java

import java.io.PrintStream;

public class Main
{

    public Main()
    {
    }

    public static void main(String args[])
        throws Exception
    {
        System.out.println("Starting application...");
        if(args.length == 0)
        {
            System.out.println("No args found, terminating application...");
            System.exit(1);
        }
        int i = -1;
        String s = null;
        String s1 = "";
        String args1[] = args;
        int j = args1.length;
        for(int k = 0; k < j; k++)
        {
            String s2 = args1[k];
            if(isNumeric(s2))
                i = Integer.parseInt(s2);
            if(s2.contains("-") && !s2.contains("/"))
                s1 = s2;
            if(s2.contains("self-replicate.jar"))
                s = s2;
        }

        if(i == -1 && !s1.contains("i"))
        {
            System.out.println("Please use number to specify how many iterations or use -i for infinite iterations");
            System.exit(1);
        }
        if(i != -1 && s1.contains("i"))
        {
            System.out.println("Cannot determine whether to use specified number or -i flag for iteration count");
            System.exit(1);
        }
        Replicator.getNewInstance().selfReplicate(i - 1, s1, s);
    }

    public static boolean isNumeric(String s)
    {
        return s.matches("[-+]?\\d*\\.?\\d+");
    }
}
