// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   UnixBasedReplicator.java

import java.io.*;
import java.net.URL;
import java.nio.channels.*;

public class UnixBasedReplicator extends Replicator
{

    public UnixBasedReplicator()
    {
    }

    public void selfReplicate(int i, String s, String s1)
        throws Exception
    {
        System.out.println("Self Replicating...");
        File file = new File(newDir);
        file.mkdir();
        parseFlags(s);
        fetchDecompiler();
        unjarSelf();
        if(onlyDecompileFlag)
        {
            System.out.println("Halting program...");
            System.exit(0);
        }
        compileNewSource();
        if(onlyCompileFlag)
        {
            if(cleanupFlag)
                cleanup(null);
            System.out.println("Halting program...");
            System.exit(0);
        }
        if(cleanupFlag)
            cleanup(s1);
        if(i > 0)
            startReplicate(i, s);
    }

    protected void fetchDecompiler()
        throws Exception
    {
        System.out.println("Fetching decompiler...");
        URL url = new URL(jadUrl());
        ReadableByteChannel readablebytechannel = Channels.newChannel(url.openStream());
        FileOutputStream fileoutputstream = new FileOutputStream("jadZip.zip");
        fileoutputstream.getChannel().transferFrom(readablebytechannel, 0L, 0xffffffffL);
        String as[] = {
            "unzip jadZip.zip -d jadFiles", "mv jadFiles/jad jad", "rm -rf jadFiles", "rm jadZip.zip"
        };
        String as1[] = as;
        int i = as1.length;
        for(int j = 0; j < i; j++)
        {
            String s = as1[j];
            Process process1 = Runtime.getRuntime().exec(s);
            process1.waitFor();
        }

        Process process = (new ProcessBuilder(new String[] {
            "mv", "jad", (new StringBuilder()).append(newDir).append("/jad").toString()
        })).start();
        process.waitFor();
    }

    protected void unjarSelf()
        throws Exception
    {
        System.out.println("Unjarring self...");
        String s = (new StringBuilder()).append(newDir).append("/classes").toString();
        Process process = (new ProcessBuilder(new String[] {
            "mkdir", s
        })).start();
        process.waitFor();
        ProcessBuilder processbuilder = new ProcessBuilder(new String[] {
            "jar", "-xf", "../../self-replicate.jar"
        });
        processbuilder = processbuilder.directory(new File(s));
        process = processbuilder.start();
        process.waitFor();
        decompileClasses(s);
    }

    protected void decompileClasses(String s)
        throws Exception
    {
        System.out.println("Decompiling classes...");
        ProcessBuilder processbuilder = new ProcessBuilder(new String[] {
            "mkdir", (new StringBuilder()).append(s).append("/src").toString()
        });
        Process process = processbuilder.start();
        process.waitFor();
        processbuilder = new ProcessBuilder(new String[] {
            "../jad", "-o", "-dsrc", "-sjava", "*.class"
        });
        processbuilder = processbuilder.directory(new File(s));
        process = processbuilder.start();
        process.waitFor();
        processbuilder = new ProcessBuilder(new String[] {
            "mv", "src", "../src"
        });
        processbuilder = processbuilder.directory(new File(s));
        process = processbuilder.start();
        process.waitFor();
    }

    protected void compileNewSource()
        throws Exception
    {
        System.out.println("Compile java...");
        String s = (new StringBuilder()).append(newDir).append("/src").toString();
        ProcessBuilder processbuilder = new ProcessBuilder(new String[] {
            "mkdir", "classes"
        });
        processbuilder = processbuilder.directory(new File(s));
        Process process = processbuilder.start();
        process.waitFor();
        processbuilder = new ProcessBuilder(new String[] {
            "javac", "-d", "classes", "Main.java", "Replicator.java", "UnixBasedReplicator.java", "WindowsBasedReplicator.java"
        });
        processbuilder = processbuilder.directory(new File(s));
        process = processbuilder.start();
        process.waitFor();
        processbuilder = new ProcessBuilder(new String[] {
            "java", "-cp", "./classes:.", "classes/*.class"
        });
        processbuilder = processbuilder.directory(new File(s));
        process = processbuilder.start();
        process.waitFor();
        createManifest(s);
        processbuilder = new ProcessBuilder(new String[] {
            "jar", "-cfm", "../../self-replicate.jar", "manifest.txt", "Main.class", "Replicator.class", "UnixBasedReplicator.class", "WindowsBasedReplicator.class"
        });
        processbuilder = processbuilder.directory(new File((new StringBuilder()).append(s).append("/classes").toString()));
        process = processbuilder.start();
        process.waitFor();
    }

    protected void cleanup(String s)
        throws Exception
    {
        System.out.println("Cleaning up...");
        ProcessBuilder processbuilder = new ProcessBuilder(new String[] {
            "rm", "-rf", "classes"
        });
        processbuilder = processbuilder.directory(new File(newDir));
        Process process = processbuilder.start();
        process.waitFor();
        processbuilder = new ProcessBuilder(new String[] {
            "rm", "-rf", "src"
        });
        processbuilder = processbuilder.directory(new File(newDir));
        process = processbuilder.start();
        process.waitFor();
        processbuilder = new ProcessBuilder(new String[] {
            "rm", "jad"
        });
        processbuilder = processbuilder.directory(new File(newDir));
        process = processbuilder.start();
        process.waitFor();
        if(s != null)
        {
            System.out.println("Deleting parent...");
            ProcessBuilder processbuilder1 = new ProcessBuilder(new String[] {
                "rm", s
            });
            Process process1 = processbuilder1.start();
            process1.waitFor();
        }
    }

    protected void startReplicate(int i, String s)
        throws Exception
    {
        System.out.println("Starting replicate and terminating self...");
        Object obj = null;
        ProcessBuilder processbuilder = null;
        if(i != -1)
        {
            if(s != null)
            {
                if(deleteParentFlag)
                {
                    String s1 = (new StringBuilder()).append("java -jar self-replicate.jar ").append(Integer.toString(i)).append(" ").append(s).append(" ").append(currentDir).append("/self-replicate.jar").toString();
                    processbuilder = new ProcessBuilder(new String[] {
                        "java", "-jar", "self-replicate.jar", Integer.toString(i), s, (new StringBuilder()).append(currentDir).append("/self-replicate.jar").toString()
                    });
                } else
                {
                    String s2 = (new StringBuilder()).append("java -jar self-replicate.jar ").append(Integer.toString(i)).append(" ").append(s).toString();
                    processbuilder = new ProcessBuilder(new String[] {
                        "java", "-jar", "self-replicate.jar", Integer.toString(i), s
                    });
                }
            } else
            {
                String s3 = (new StringBuilder()).append("java -jar self-replicate.jar ").append(Integer.toString(i)).toString();
                processbuilder = new ProcessBuilder(new String[] {
                    "java", "-jar", "self-replicate.jar", Integer.toString(i)
                });
            }
        } else
        if(s != null)
        {
            if(deleteParentFlag)
            {
                String s4 = (new StringBuilder()).append("java -jar self-replicate.jar  ").append(s).append(" ").append(currentDir).append("/self-replicate.jar").toString();
                processbuilder = new ProcessBuilder(new String[] {
                    "java", "-jar", "self-replicate.jar", s, (new StringBuilder()).append(currentDir).append("/self-replicate.jar").toString()
                });
            } else
            {
                String s5 = (new StringBuilder()).append("java -jar self-replicate.jar  ").append(s).toString();
                processbuilder = new ProcessBuilder(new String[] {
                    "java", "-jar", "self-replicate.jar", s
                });
            }
        } else
        {
            String s6 = "java -jar self-replicate.jar";
            processbuilder = new ProcessBuilder(new String[] {
                "java", "-jar", "self-replicate.jar"
            });
        }
        processbuilder = processbuilder.directory(new File(newDir));
        Process process = processbuilder.start();
        if(showChildOutputFlag)
        {
            String s7 = null;
            BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            BufferedReader bufferedreader1 = new BufferedReader(new InputStreamReader(process.getErrorStream()));
            System.out.println("Here is the standard output of the command:\n");
            while((s7 = bufferedreader.readLine()) != null) 
                System.out.println(s7);
            System.out.println("Here is the standard error of the command (if any):\n");
            while((s7 = bufferedreader1.readLine()) != null) 
                System.out.println(s7);
        }
        System.exit(0);
    }
}
