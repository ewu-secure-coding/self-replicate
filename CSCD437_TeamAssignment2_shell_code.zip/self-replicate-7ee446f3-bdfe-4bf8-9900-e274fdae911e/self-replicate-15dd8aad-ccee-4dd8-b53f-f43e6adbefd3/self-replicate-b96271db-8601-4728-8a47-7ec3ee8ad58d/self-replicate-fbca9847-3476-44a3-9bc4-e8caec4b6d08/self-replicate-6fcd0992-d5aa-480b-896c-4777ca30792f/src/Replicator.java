// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Replicator.java

import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.UUID;

public abstract class Replicator
{

    public Replicator()
    {
        currentDir = System.getProperty("user.dir");
        newDir = (new StringBuilder()).append(currentDir).append("/self-replicate-").append(UUID.randomUUID()).toString();
        os = System.getProperty("os.name");
    }

    public static Replicator getNewInstance()
    {
        if(System.getProperty("os.name").contains("Windows"))
        {
            System.out.println("Using Windows based replicator...");
            return new WindowsBasedReplicator();
        } else
        {
            System.out.println("Using Unix based replicator...");
            return new UnixBasedReplicator();
        }
    }

    protected void parseFlags(String s)
    {
        System.out.println("Parsing flags...");
        infiniteFlag = onlyDecompileFlag = onlyCompileFlag = deleteParentFlag = cleanupFlag = showChildOutputFlag = false;
        if(s.contains("i"))
            infiniteFlag = true;
        if(s.contains("d") && !s.contains("c"))
            onlyDecompileFlag = true;
        if(s.contains("c") && !s.contains("d"))
            onlyCompileFlag = true;
        if(s.contains("p"))
            deleteParentFlag = true;
        if(s.contains("x"))
            cleanupFlag = true;
        if(s.contains("s"))
            showChildOutputFlag = true;
    }

    protected String jadUrl()
    {
        if(os.contains("Windows"))
            return "http://varaneckas.com/jad/jad158g.win.zip";
        if(os.contains("Mac"))
            return "http://varaneckas.com/jad/jad158g.mac.intel.zip";
        if(os.contains("Linux"))
            return "http://varaneckas.com/jad/jad158e.linux.static.zip";
        else
            return null;
    }

    protected void createManifest(String s)
        throws Exception
    {
        PrintWriter printwriter = new PrintWriter((new StringBuilder()).append(s).append("/classes/manifest.txt").toString());
        printwriter.println("Manifest-Version: 1.0");
        printwriter.println("Main-Class: Main");
        printwriter.println("");
        printwriter.flush();
        printwriter.close();
    }

    public abstract void selfReplicate(int i, String s, String s1)
        throws Exception;

    protected abstract void fetchDecompiler()
        throws Exception;

    protected abstract void unjarSelf()
        throws Exception;

    protected abstract void decompileClasses(String s)
        throws Exception;

    protected abstract void compileNewSource()
        throws Exception;

    protected abstract void cleanup(String s)
        throws Exception;

    protected abstract void startReplicate(int i, String s)
        throws Exception;

    protected String currentDir;
    protected String newDir;
    protected String os;
    protected boolean infiniteFlag;
    protected boolean onlyDecompileFlag;
    protected boolean onlyCompileFlag;
    protected boolean deleteParentFlag;
    protected boolean cleanupFlag;
    protected boolean showChildOutputFlag;
}
